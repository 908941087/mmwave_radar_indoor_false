^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.1 (2015-04-06)
------------------
* remove laptop charge status message `#2 <https://github.com/turtlebot/turtlebot_msgs/issues/2>`_
* LaptopChargeStatus moved here from turtlebot stack.
* Contributors: Daniel Stonier, Jihoon Lee

2.2.0 (2013-08-30)
------------------
* Changelog added


2.1.x - hydro, unstable
=======================

2.1.0 (2013-08-16)
------------------
* First release.
