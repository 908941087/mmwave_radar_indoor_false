^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot_actions
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.3.7 (2016-11-01)
------------------

2.3.6 (2016-06-29)
------------------

2.3.5 (2016-06-28)
------------------

2.3.4 (2016-06-28)
------------------

2.3.3 (2015-03-23)
------------------

2.3.2 (2015-01-21)
------------------

2.3.1 (2014-12-30)
------------------

2.3.0 (2014-12-30)
------------------
* Change build commands to fix break caused by Eigen package moving to cmake_modules
* find eigen with cmake_modules, fixes `#88 <https://github.com/turtlebot/turtlebot_apps/issues/88>`_.
* update matrix types for image_geometry api change, `#87 <https://github.com/turtlebot/turtlebot_apps/issues/87>`_.
* Contributors: Daniel Stonier, Paul Bouchier

2.2.4 (2013-10-14)
------------------

2.2.3 (2013-09-27)
------------------

2.2.2 (2013-09-26)
------------------

2.2.1 (2013-09-23)
------------------

2.2.0 (2013-08-30)
------------------
* Add bugtracker and repo info URLs.
* Rename include launchers to *.launch.xml.
* Changelogs at package level.
* Do not use deprecated action server API.

2.1.x - hydro, unstable
=======================

2.1.1 (2013-08-09)
------------------

2.1.0 (2013-07-19)
------------------
* Catkinized
* Set OSRF as maintainer


Previous versions, bugfixing
============================

Available in ROS wiki: http://ros.org/wiki/turtlebot_apps/ChangeList
